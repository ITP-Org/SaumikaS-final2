import React from "react";
import ReactPlayer from "react-player";

const Video_player = () => {
  const URLlink =
    "https://www.youtube.com/watch?v=h24UmH38_LI&pp=ygUOQ292YWxlbnQgQm9uZHM%3D";

  return (
    <div className="fullscreen-player">
      <ReactPlayer
        className="fullscreen-reactplayer"
        url={URLlink}
        controls={true}
        width={2000}
        height={480}
      />
    </div>
  );
};
export default Video_player;
