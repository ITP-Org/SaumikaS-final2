import React, { useState, useEffect } from "react";
import "../CSS Files/admin_css.css";

const ContentForm = () => {
  const [formData, setFormData] = useState({
    title: "",
    img: "",
    content: [{ sub_content: "", No_of_tutes: 0 }],
  });
  const [loading, setLoading] = useState(false);
  const [responseMessage, setResponseMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [contents, setContents] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentContentId, setCurrentContentId] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleContentChange = (index, e) => {
    const { name, value } = e.target;
    const updatedContent = [...formData.content];
    updatedContent[index] = { ...updatedContent[index], [name]: value };
    setFormData({ ...formData, content: updatedContent });
  };

  const addSubContent = () => {
    setFormData({
      ...formData,
      content: [...formData.content, { sub_content: "", No_of_tutes: 0 }],
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const url = isEditing
        ? `http://localhost:5000/content/update/${currentContentId}`
        : "http://localhost:5000/content/add";
      const response = await fetch(url, {
        method: isEditing ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Failed to submit content");
      }

      const result = await response.json();
      setResponseMessage(result.message);
      setErrorMessage("");
      fetchContents(); // Fetch contents after successful submission

      // Reset form data
      resetForm();
    } catch (error) {
      setErrorMessage("Error submitting form: " + error.message);
      setResponseMessage("");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      img: "",
      content: [{ sub_content: "", No_of_tutes: 0 }],
    });
    setIsEditing(false);
    setCurrentContentId(null);
  };

  const deleteContent = async (id) => {
    if (window.confirm("Are you sure you want to delete this content?")) {
      try {
        const response = await fetch(
          `http://localhost:5000/content/delete/${id}`,
          {
            method: "DELETE",
          }
        );

        if (!response.ok) {
          throw new Error("Failed to delete content");
        }

        const result = await response.json();
        setResponseMessage(result.message);
        fetchContents(); // Refresh the content list
      } catch (error) {
        setErrorMessage("Error deleting content: " + error.message);
      }
    }
  };

  const editContent = (content) => {
    setFormData({
      title: content.title,
      img: content.img,
      content: content.content,
    });
    setIsEditing(true);
    setCurrentContentId(content._id); // Store the content ID
  };

  const fetchContents = async () => {
    try {
      const response = await fetch("http://localhost:5000/content");
      if (!response.ok) {
        throw new Error("Failed to fetch content");
      }
      const data = await response.json();
      setContents(data);
    } catch (error) {
      console.error("Error fetching contents:", error);
    }
  };

  useEffect(() => {
    fetchContents();
  }, []);

  return (
    <div className="content-wrapper">
      <div className="form">
        <h2>{isEditing ? "Update Content" : "Submit Content"}</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor="title">Title*</label>
          <input
            type="text"
            name="title"
            id="title"
            placeholder="Enter content title"
            value={formData.title}
            onChange={handleChange}
            required
          />

          <label htmlFor="img">Image URL*</label>
          <input
            type="text"
            name="img"
            id="img"
            placeholder="Enter image URL"
            value={formData.img}
            onChange={handleChange}
            required
          />

          {formData.content.map((contentItem, index) => (
            <div key={index}>
              <label htmlFor={`sub_content_${index}`}>Sub Content*</label>
              <input
                type="text"
                name="sub_content"
                id={`sub_content_${index}`}
                placeholder="Enter sub content"
                value={contentItem.sub_content}
                onChange={(e) => handleContentChange(index, e)}
                required
              />

              <label htmlFor={`No_of_tutes_${index}`}>Number of Tutes*</label>
              <input
                type="number"
                name="No_of_tutes"
                id={`No_of_tutes_${index}`}
                placeholder="Enter number of tutorials"
                value={contentItem.No_of_tutes}
                onChange={(e) => handleContentChange(index, e)}
                required
              />
            </div>
          ))}

          <button type="button" onClick={addSubContent}>
            Add Sub Content
          </button>

          <button type="submit" disabled={loading}>
            {loading ? "Submitting..." : "Submit"}
          </button>

          {responseMessage && (
            <p className="success-message">{responseMessage}</p>
          )}
          {errorMessage && <p className="error-message">{errorMessage}</p>}
        </form>
      </div>

      <div className="data-table">
        <h2>Submitted Content</h2>
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Image URL</th>
              <th>Sub Content</th>
              <th>Number of Tutes</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {contents.map((content) =>
              content.content.map((subContent, index) => (
                <tr key={index}>
                  {index === 0 ? (
                    <>
                      <td rowSpan={content.content.length}>{content.title}</td>
                      <td rowSpan={content.content.length}>{content.img}</td>
                    </>
                  ) : null}
                  <td>{subContent.sub_content}</td>
                  <td>{subContent.No_of_tutes}</td>
                  <td>
                    <button onClick={() => editContent(content)}>Edit</button>
                    <button onClick={() => deleteContent(content._id)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ContentForm;
