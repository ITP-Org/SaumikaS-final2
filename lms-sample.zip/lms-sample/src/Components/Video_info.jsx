const Video_info = () => {
  return (
    <div className="video_info">
      <h1>Introduction to Astrophysic</h1>
      <p>
        {" "}
        Astrophysics is the branch of astronomy that employs the principles of
        physics and chemistry "
      </p>
    </div>
  );
};
export default Video_info;
