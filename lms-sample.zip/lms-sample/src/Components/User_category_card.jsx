import React from "react";

const User_category_card = () => {
  return <></>;
};
export default User_category_card;
