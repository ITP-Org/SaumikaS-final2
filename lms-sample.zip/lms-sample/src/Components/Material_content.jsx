import React from "react";

const Material_content = () => {
  return (
    <div className="material-description">
      <h1 id="lesson-title-id">Introduction to subject</h1>
      <div className="modern-underline"></div>

      <p id="lesson-description-id">Lesson Description</p>

      {/*       <div className="grid-box">
        <div className="grid-box-content">
          <div className="grid-icon"></div>
          <div classname="grid-name">
            <b>Author :</b>
          </div>
          <div className="grid-value">Neil deGrasse Tyson</div>
        </div>
        <div className="grid-box-content">
          <div className="grid-icon"></div>
          <div classname="grid-name">
            {" "}
            <b>Date Uploaded : </b>
          </div>
          <div className="grid-value">2024-07-02 14:23:54 </div>
        </div>
        <div className="grid-box-content">
          <div className="grid-icon"></div>
          <div classname="grid-name">
            {" "}
            <b>Resources : </b>
          </div>
          <div className="grid-value">“The Universe in a Nutshell”</div>
        </div>
      </div> */}
    </div>
  );
};

export default Material_content;
