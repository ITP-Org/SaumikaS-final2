import React, { useState, useEffect } from "react";
import Expander from "../Components/Expander";
import Material_content from "../Components/Material_content";
import Lessons from "../Dataset/Lessons.json";
import Player from "../Components/Video_player";
import { BrowserRouter, Link } from "react-router-dom";
import Selective_card from "../Components/Selective_card";
import Lesson_card from "../Components/Lesson_card";
import axios from "axios";
import Footer from "../Components/Footer";

function Course_content() {
  const [lessons_set, setLessonSet] = useState([]);
  const [lesson_array, setArray] = useState([]);
  const [material_array, setMaterialArray] = useState([]);
  const [videoURL, setVideoURL] = useState("");

  useEffect(() => {
    const fetchcontent = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/contents/getAll"
        );
        console.log("Axios is running");
        setLessonSet(response.data.Content);
        console.log("Axios is running 2");
      } catch (error) {
        console.error("Error fetching inquiries:", error);
      }
    };
    fetchcontent();
  }, []);

  return (
    <div className="lmsapp">
      <div className="rectangle"></div>

      <div className="grid1">
        <div className="titlename">
          <div className="title-header">Lectures</div>
        </div>

        <div className="Expander-class">
          <div className="Expander-class-inner-1">
            {Lessons.map((item, index) => {
              const setSublesson = () => {
                setArray(Lessons[index]?.content || []); // Safely access 'content'
                setMaterialArray(Lessons[index]?.materials || []); // Safely access 'materials'
              };
              return (
                <>
                  <Lesson_card
                    key={index}
                    item={item}
                    index={index}
                    setSublesson={setSublesson}
                  />
                </>
              );
            })}
          </div>
          <div className="Expander-class-inner-2">
            {
              <Selective_card
                SubLessonArray={lesson_array}
                set_Video_URL={setVideoURL}
              />
            }
          </div>
        </div>
      </div>

      <div className="grid2">
        <Link
          to={{
            pathname: "/Video-resource",
            state: { materials: material_array, videoURL: videoURL },
          }}
        >
          <h1 className="video-header">Content Video Player</h1>
        </Link>

        <div className="video-player">
          <Player URL={videoURL} />
        </div>

        <div className="material-content">
          <Material_content />
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default Course_content;
