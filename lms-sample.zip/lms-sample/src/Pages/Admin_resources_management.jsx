import React from "react";
import Admin_video_card from "../Components/Admin_video_card";

function admin_resources_management() {
  return (
    <>
      <div className="container">
        <Admin_video_card />
      </div>
    </>
  );
}
export default admin_resources_management;
