import React from "react";
const { useState } = React;

const Payment_Management = () => {
  const [cartItems, setCartItems] = useState([
    { id: 1, name: "Atomic structure", price: 2000 },
    { id: 2, name: "Resonance structure", price: 1500 },
    { id: 3, name: "Model past papers I", price: 1500 },
  ]);

  const [activeTab, setActiveTab] = useState("card");
  const [transactions, setTransactions] = useState([]);
  const [paidItems, setPaidItems] = useState([]);
  const [paymentInfo, setPaymentInfo] = useState({
    method: "",
    name: "",
    number: "",
    expiration: "",
  });

  const removeItem = (id) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);

  const handleCheckout = () => {
    setTransactions([
      ...transactions,
      { type: "Card Payment", amount: totalPrice, status: "Paid" },
    ]);
    setPaidItems(cartItems);
    setCartItems([]);
    setPaymentInfo({
      method: "Card Payment",
      name: "",
      number: "",
      expiration: "",
    });
  };

  const handleSlipSubmit = () => {
    setTransactions([
      ...transactions,
      { type: "Payment Slip", amount: totalPrice, status: "Pending" },
    ]);
    setPaidItems(cartItems);
    setCartItems([]);
    setPaymentInfo({
      method: "Payment Slip",
      name: "",
      number: "",
      expiration: "",
    });
  };

  const handleTransactionClick = (transaction) => {
    setCartItems(paidItems);
    setPaymentInfo({
      method: transaction.type,
      name: "",
      number: "",
      expiration: "",
    });
  };

  const showPaymentGuideline = () => {
    const guidelineText =
      "Payment Guideline:\n\n1. Ensure you have selected the correct items in your cart.\n2. Choose your preferred payment method.\n3. For card payments, enter your card details and ensure they are correct.\n4. For payment slips, upload a clear image of the slip.\n5. Click 'Checkout' or 'Submit Slip' to complete the payment.\n6. You will receive a confirmation once the payment is processed.";
    const blob = new Blob([guidelineText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");
    downloadLink.href = url;
    downloadLink.download = "Payment_Guideline.txt";
    downloadLink.innerText = "Download Payment Guideline";
    downloadLink.className =
      "bg-purple-500 text-white px-4 py-2 rounded-full mt-4 inline-block";

    alert(guidelineText);
    document.body.appendChild(downloadLink);
  };

  return (
    <div class="p-8">
      <header class="flex justify-between items-center mb-8">
        <img
          src="https://placehold.co/150x50?text=Logo"
          alt="Logo"
          class="h-12"
        />
        <nav class="flex space-x-8">
          <a href="#" class="text-purple-700 hover:text-purple-900">
            Home
          </a>
          <a href="#" class="text-purple-700 hover:text-purple-900">
            Course Content
          </a>
          <a href="#" class="text-purple-700 hover:text-purple-900">
            Forum
          </a>
          <a href="#" class="text-purple-700 hover:text-purple-900">
            Cart
          </a>
        </nav>
        <button class="bg-purple-200 text-purple-700 px-4 py-2 rounded-full">
          Logout
        </button>
      </header>
      <main class="flex justify-between space-x-8">
        <section class="w-2/3">
          <h1 class="text-3xl font-semibold mb-6">Cart</h1>
          {cartItems.map((item) => (
            <div
              key={item.id}
              class="cart-item p-4 rounded-lg mb-4 flex justify-between items-center hover:bg-purple-200"
            >
              <span>{item.name}</span>
              <span>LKR {item.price.toLocaleString()}</span>
              <button
                onClick={() => removeItem(item.id)}
                class="text-purple-700"
              >
                <i class="fas fa-times"></i>
              </button>
            </div>
          ))}
          <div class="flex justify-between items-center bg-purple-100 p-4 rounded-lg">
            <div class="flex items-center">
              <i class="fas fa-shopping-cart text-purple-700 mr-2"></i>
              <span>Total Price</span>
            </div>
            <span class="text-2xl font-semibold">
              LKR {totalPrice.toLocaleString()}
            </span>
          </div>
          <div class="flex space-x-4 mt-4">
            <button
              onClick={showPaymentGuideline}
              class="bg-purple-500 text-white px-4 py-2 rounded-full flex items-center"
            >
              <i class="fas fa-file-alt mr-2"></i> Payment guideline
            </button>
            <button class="bg-purple-500 text-white px-4 py-2 rounded-full flex items-center">
              <i class="fas fa-arrow-left mr-2"></i> Back to course
            </button>
          </div>
        </section>
        <section class="w-1/3 bg-purple-100 p-8 rounded-lg">
          <h2 class="text-2xl font-semibold mb-6">Payment info</h2>
          <div class="flex mb-4">
            <button
              onClick={() => setActiveTab("card")}
              class={`w-1/2 p-2 ${
                activeTab === "card"
                  ? "bg-purple-500 text-white"
                  : "bg-purple-200 text-purple-700"
              } rounded-l-lg`}
            >
              Card Payment
            </button>
            <button
              onClick={() => setActiveTab("slip")}
              class={`w-1/2 p-2 ${
                activeTab === "slip"
                  ? "bg-purple-500 text-white"
                  : "bg-purple-200 text-purple-700"
              } rounded-r-lg`}
            >
              Payment Slip
            </button>
          </div>
          <div
            class={`tab-content ${
              activeTab === "card" ? "opacity-100" : "opacity-0"
            }`}
          >
            {activeTab === "card" && (
              <div>
                <div class="flex justify-end mb-4">
                  <img
                    src="https://placehold.co/100x30?text=Payment+Methods"
                    alt="Payment Methods"
                  />
                </div>
                <div class="mb-4">
                  <label class="block mb-2">Payment method</label>
                  <button class="bg-purple-500 text-white px-4 py-2 rounded-full">
                    Debit card
                  </button>
                </div>
                <div class="mb-4">
                  <label class="block mb-2">Name on card :</label>
                  <input
                    type="text"
                    placeholder="Enter your name"
                    class="w-full p-2 border border-purple-300 rounded-lg"
                  />
                </div>
                <div class="mb-4">
                  <label class="block mb-2">Card number :</label>
                  <input
                    type="text"
                    placeholder="XXXX - XXXX -XXXX xx"
                    class="w-full p-2 border border-purple-300 rounded-lg"
                  />
                </div>
                <div class="mb-4">
                  <label class="block mb-2">Expiration date :</label>
                  <div class="flex space-x-2">
                    <select class="p-2 border border-purple-300 rounded-lg">
                      <option>MM</option>
                    </select>
                    <select class="p-2 border border-purple-300 rounded-lg">
                      <option>DD</option>
                    </select>
                    <select class="p-2 border border-purple-300 rounded-lg">
                      <option>YYYY</option>
                    </select>
                  </div>
                </div>
                <button
                  onClick={handleCheckout}
                  class="bg-purple-500 text-white w-full py-2 rounded-full"
                >
                  Checkout
                </button>
              </div>
            )}
          </div>
          <div
            class={`tab-content ${
              activeTab === "slip" ? "opacity-100" : "opacity-0"
            }`}
          >
            {activeTab === "slip" && (
              <div>
                <div class="mb-4">
                  <label class="block mb-2">Slip upload</label>
                  <input
                    type="file"
                    class="w-full p-2 border border-purple-300 rounded-lg"
                  />
                </div>
                <button
                  onClick={handleSlipSubmit}
                  class="bg-purple-500 text-white w-full py-2 rounded-full"
                >
                  Submit slip
                </button>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Payment_Management;
