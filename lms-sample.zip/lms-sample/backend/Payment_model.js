const mongoose = require("mongoose");

const PaymentSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  Payment_slip: { type: String, required: true },
  status: { type: String, required: true },
  cart: [
    {
      Lesson: String,
      amount: Number,
    },
  ],
});

const Content = mongoose.model("Payment", PaymentSchema);
module.exports = Content;
