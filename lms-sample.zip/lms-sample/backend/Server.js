const express = require("express");
const mongoose = require("mongoose");
const password = encodeURIComponent("Pasi@1234");

const app = express();
const cors = require("cors");

// Middleware
app.use(express.json());
app.use(cors());

const contentRoutes = require("./routes/contentRoutes");
app.use("/content", contentRoutes);

// Database connection URI
let uri = `mongodb+srv://pasinduhansana:${password}@lms.4n1df.mongodb.net/?retryWrites=true&w=majority&appName=LMS`;

// Database connection
mongoose
  .connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB");
    app.listen(5000, () => {
      console.log("Server running on port 5000");
    });
  })
  .catch((err) => console.log("Error connecting to MongoDB:", err));
