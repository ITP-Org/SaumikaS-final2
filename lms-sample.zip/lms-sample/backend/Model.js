const mongoose = require("mongoose");

const contentSchema = new mongoose.Schema({
  title: { type: String, required: true },
  img: { type: String, required: true },
  content: [
    {
      sub_content: String,
      No_of_tutes: Number,
    },
  ],
});

const Content = mongoose.model("inquiries", contentSchema);
module.exports = Content;
