const Content = require("./Model");

const getcontent = async (req, res) => {
  try {
    const contents = await Content.find();
    return res.status(200).json({ contents });
  } catch (err) {
    console.error("Error retrieving inquiries:", err);
    return res.status(500).json({
      message: "Server error occurred while retrieving inquiries.",
      error: err.message,
    });
  }
};

const getcontentbyID = async (req, res) => {
  const contentID = req.params.id;

  if (!mongoose.Types.ObjectId.isValid(contentID)) {
    return res.status(400).json({ message: "Invalid inquiry ID format." });
  }

  try {
    const content = await Content.findById(contentID);
    if (!content) {
      return res.status(404).json({ message: "Inquiry details not found." });
    }
    return res.status(200).json({ content });
  } catch (err) {
    console.error("Error retrieving inquiry:", err);
    return res.status(500).json({
      message: "Server error occurred while retrieving inquiry.",
      error: err.message,
    });
  }
};

const addInquiry = async (req, res) => {
  const { fullName, subject, email, phone, message } = req.body;

  try {
    const inquiry = new Inquiry({ fullName, subject, email, phone, message });
    await inquiry.save();
    return res.status(201).json({ inquiry });
  } catch (err) {
    console.error("Error adding inquiry:", err);
    return res
      .status(500)
      .json({ message: "Server error occurred while adding inquiry." });
  }
};

module.exports = {
  getcontent,
  getcontentbyID,
  addInquiry,
};
