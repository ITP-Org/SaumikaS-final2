const mongoose = require("mongoose");

const sampletSchema = new mongoose.Schema({
  title: { type: String, required: true },
  img: { type: String, required: true },
  content: { type: String, required: true },
});

const Content = mongoose.model("inquiries", sampletSchema);
module.exports = Content;
