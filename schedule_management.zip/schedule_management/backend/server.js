const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
const Schedule = require("./model/Schedule");

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose
  .connect(
    "mongodb+srv://pasinduhansana:Pasi%401234@lms.4n1df.mongodb.net/?retryWrites=true&w=majority&appName=LMS"
  )
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.log(err));

// Example API route
app.get("/", (req, res) => {
  res.send("Server is running");
});

console.log(Schedule.collection.name);

// Route to print the first schedule from the database
app.get("/print-first-schedule", async (req, res) => {
  try {
    const schedules = await Schedule.find(); // Fetch all schedules

    if (schedules.length > 0) {
      const firstSchedule = schedules[0]; // Get the first schedule
      console.log("First Schedule Title:", firstSchedule.title); // Print the title of the first schedule
      res.json(firstSchedule); // Send the first schedule as a response
    } else {
      console.log("No schedules found");
      res.status(404).send("No schedules found");
    }
  } catch (err) {
    console.error("Error fetching schedules:", err);
    res.status(500).send("Error fetching schedules");
  }
});


// Route to add a new schedule
app.post("/add-schedule", async (req, res) => {
    const { title, description, venue, date_time } = req.body;
  
    if (!title || !description || !venue || !date_time) {
      return res.status(400).send("All fields are required");
    }
  
    try {
      const newSchedule = new Schedule({
        title,
        description,
        venue,
        date_time: new Date(date_time) // Ensure it's saved as a valid Date object
      });
  
      await newSchedule.save();
      res.status(201).send("Schedule added successfully");
    } catch (err) {
      console.error("Error adding schedule:", err);
      res.status(500).send("Error adding schedule");
    }
  });
  
  app.get("/get-schedules", async (req, res) => {
    try {
      const schedules = await Schedule.find();
      res.json(schedules);
    } catch (err) {
      console.error("Error fetching schedules:", err);
      res.status(500).send("Error fetching schedules");
    }
  });
  
  // Update schedule
  app.put("/update-schedule/:id", async (req, res) => {
    const { id } = req.params;
    const { title, description, venue, date_time } = req.body;
  
    if (!title || !description || !venue || !date_time) {
      return res.status(400).send("All fields are required");
    }
  
    try {
      const updatedSchedule = await Schedule.findByIdAndUpdate(
        id,
        { title, description, venue, date_time: new Date(date_time) },
        { new: true }
      );
      res.json(updatedSchedule);
    } catch (err) {
      console.error("Error updating schedule:", err);
      res.status(500).send("Error updating schedule");
    }
  });
  
  // Delete schedule
  app.delete("/delete-schedule/:id", async (req, res) => {
    const { id } = req.params;
  
    try {
      await Schedule.findByIdAndDelete(id);
      res.send("Schedule deleted successfully");
    } catch (err) {
      console.error("Error deleting schedule:", err);
      res.status(500).send("Error deleting schedule");
    }
  });
   
// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server running on port' + {PORT}));