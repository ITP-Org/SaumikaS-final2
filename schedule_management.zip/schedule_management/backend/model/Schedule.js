const mongoose = require("mongoose");

const scheduleSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  venue: {
    type: String,
    required: true,
  },
  date_time: {
    type: Date,
    required: true,
  },
});

const Schedule = mongoose.model("schedules", scheduleSchema);

module.exports = Schedule;