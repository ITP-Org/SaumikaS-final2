import React, { useState, useEffect } from "react";
import './TaskForm.css';
import jsPDF from 'jspdf';
import 'jspdf-autotable'; 
import logo from './assets/logo.jpeg';


const TaskForm = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [venue, setVenue] = useState('');
  const [errors, setErrors] = useState({});
  const [tasks, setTasks] = useState([]); // Store fetched tasks here
  const [editTaskId, setEditTaskId] = useState(null); // For task being edited
  const [searchQuery, setSearchQuery] = useState(''); // State for search query
  const [dateSearchQuery, setDateSearchQuery] = useState(''); // State for date search query

  useEffect(() => {
    // Fetch tasks from the server when component mounts
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await fetch('http://localhost:5000/get-schedules');
      const data = await response.json();
      setTasks(data); // Set the retrieved tasks into the state
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  const validate = () => {
    let tempErrors = {};
    if (!title) tempErrors.title = "Title is required";
    if (!description) tempErrors.description = "Description is required";
    if (!date) tempErrors.date = "Date is required";
    if (!time) tempErrors.time = "Time is required";
    if (!venue) tempErrors.venue = "Venue is required";
    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      const newTask = {
        title,
        description,
        date_time: new Date(`${date}T${time}`),
        venue
      };

      try {
        let response;
        if (editTaskId) {
          // Update task
          response = await fetch(`http://localhost:5000/update-schedule/${editTaskId}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(newTask),
          });
        } else {
          // Add task
          response = await fetch('http://localhost:5000/add-schedule', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(newTask),
          });
        }

        if (response.ok) {
          alert("Task saved successfully");
          fetchTasks(); // Refresh tasks after adding/updating
          setTitle('');
          setDescription('');
          setDate('');
          setTime('');
          setVenue('');
          setErrors({});
          setEditTaskId(null); // Reset the edit task ID
        } else {
          alert("Error saving task");
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred while saving the task");
      }
    }
  };

  const handleEdit = (task) => {
    setTitle(task.title);
    setDescription(task.description);
    const [taskDate, taskTime] = new Date(task.date_time).toISOString().split('T');
    setDate(taskDate);
    setTime(taskTime.slice(0, 5)); // Format time to HH:mm
    setVenue(task.venue);
    setEditTaskId(task._id);
  };

  const handleDelete = async (taskId) => {
    try {
      const response = await fetch(`http://localhost:5000/delete-schedule/${taskId}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Task deleted successfully");
        fetchTasks(); // Refresh tasks after deletion
      } else {
        alert("Error deleting task");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the task");
    }
  };


  const exportToPDF = () => {
    const doc = new jsPDF(); // Initialize doc here
  
    // Load logo
    const imgWidth = 50;
    const imgHeight = 20;
    doc.addImage(logo, 'JPEG', 150, 25, imgWidth, imgHeight); 
  
    // Add title
    doc.setFontSize(18);
    doc.text("LMS : Schedule Management Report", 14, 22); 
  
    // Add dynamic string
    doc.setFontSize(12);
    doc.text(`Report generated on: ${new Date().toLocaleDateString()}`, 14, 30); 
  
    // Add summary
    doc.text("Summary of all scheduled tasks:", 14, 40); 
  
    // Table content
    const tableColumn = ["Title", "Description", "Date", "Time", "Venue"];
    const tableRows = [];
    
    tasks.forEach(task => {
      const taskData = [
        task.title,
        task.description,
        new Date(task.date_time).toLocaleDateString(),
        new Date(task.date_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        task.venue
      ];
      tableRows.push(taskData);
    });
  
    // Add autoTable
    doc.autoTable({
      startY: 50,
      head: [tableColumn],
      body: tableRows,
    });
  
    // Save the PDF
    doc.save('tasks_report.pdf');
  };  

 // Filter tasks based on both title/description and date
 const filteredTasks = tasks.filter(task => {
  const taskDate = new Date(task.date_time).toLocaleDateString(); // Convert task date to string for comparison
  const dateMatch = dateSearchQuery === '' || taskDate.includes(dateSearchQuery);
  const titleDescMatch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase());
  return dateMatch && titleDescMatch;
});
  return (
    <div>
       
      <form className="task-form" onSubmit={handleSubmit}>

       <div className="form-group">
         <label>Date</label>
         <input
           type="date"
           value={date}
           onChange={(e) => setDate(e.target.value)}
           className={errors.date ? 'error-input' : ''}
         />
         {errors.date && <span className="error-text">{errors.date}</span>}
       </div>
       <div className="form-group">
         <label>Time</label>
         <input
           type="time"
           value={time}
           onChange={(e) => setTime(e.target.value)}
           className={errors.time ? 'error-input' : ''}
         />
         {errors.time && <span className="error-text">{errors.time}</span>}
       </div>
       <div className="form-group">
         <label>Title</label>
         <input
           type="text"
           value={title}
           onChange={(e) => setTitle(e.target.value)}
           className={errors.title ? 'error-input' : ''}
           placeholder="Add title"
         />
         {errors.title && <span className="error-text">{errors.title}</span>}
       </div>
       <div className="form-group">
         <label>Description</label>
         <textarea
           value={description}
           onChange={(e) => setDescription(e.target.value)}
           className={errors.description ? 'error-input' : ''}
           placeholder="Add your description"
         />
         {errors.description && <span className="error-text">{errors.description}</span>}
       </div>
       <div className="form-group">
         <label>Venue</label>
         <input
           type="text"
           value={venue}
           onChange={(e) => setVenue(e.target.value)}
           className={errors.venue ? 'error-input' : ''}
           placeholder="Add venue"
         />
       {errors.venue && <span className="error-text">{errors.venue}</span>}
       </div>

        <button type="submit" className="add-task-button">
          {editTaskId ? "Update task" : "Add schedule"}
        </button>
       
      </form>
      <button onClick={exportToPDF} className="export-pdf-button">Export to PDF</button>

     {/* Search Input */}
     <input
        type="text"
        placeholder="Search tasks..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="search-input"
      />
      {/* Search Input for Date */}
<input
  type="text"
  placeholder="Search tasks by date (MM/DD/YYYY)..."
  value={dateSearchQuery}
  onChange={(e) => setDateSearchQuery(e.target.value)}
  className="search-date-input"
/>
      
      {/* Table to display tasks */}
      <table className="task-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Date</th>
            <th>Time</th>
            <th>Venue</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredTasks.map((task) => (
            <tr key={task._id}>
              <td>{task.title}</td>
              <td>{task.description}</td>
              <td>{new Date(task.date_time).toLocaleDateString()}</td>
              <td>{new Date(task.date_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
              <td>{task.venue}</td>
              <td>
                <button onClick={() => handleEdit(task)}>Edit</button>
                <button onClick={() => handleDelete(task._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TaskForm;
