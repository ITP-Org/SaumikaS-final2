import Dashboard from "./dashboard";
import TaskForm from "./Taskform";



function App() {
  return(
    <>
    <Dashboard/>
     <TaskForm/>
     
    
    </>
  );

}

export default App
