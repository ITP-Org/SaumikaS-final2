import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import '@fullcalendar/common/main.css';
import '@fullcalendar/daygrid/main.css';
import './MyCalendar.css';

const MyCalendar = () => {
  const [events, setEvents] = useState([
    { title: 'Sample Event', date: '2024-12-08' },
    { title: 'Another Event', date: '2024-12-20' },
  ]);

  const handleDateClick = (arg) => {
    const title = window.prompt('New Event name');
    if (title) {
      setEvents([...events, { title, date: arg.dateStr }]);
    }
  };

  return (
    <FullCalendar
      plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
      initialView="dayGridMonth"
      events={events}
      dateClick={handleDateClick}
      eventContent={renderEventContent}
    />
  );
};

const renderEventContent = (eventInfo) => {
  return <span style={{ backgroundColor: '#d1f7d1' }}>{eventInfo.event.title}</span>;
};

export default MyCalendar;
