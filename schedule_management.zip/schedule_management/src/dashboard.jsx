import React from 'react';
import './Dashboard.css'; 


function Dashboard(){
    return(
  <>
  
        <div className="dashboard-container">
      <Sidebar />
      <div className="dashboard-content">
      <header className="dashboard-header">
          <h4>Dashboard</h4>
          <h2>Welcome, Saumika Senanayake!</h2>
        </header>
        <div className="dashboard-main">
          <div className="stats-section">
            <StatCard
              title="Your total registered users"
              count="2000"
              icon="fa fa-users" 
            />
            <StatCard
              title="Your total content published"
              count="50"
              icon="fa fa-file-alt"
            />
          </div>
          <div className="calendar-section">
            {/* { <TaskForm /> } */
            
            }
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

const Sidebar = () => {
  return (
    <div className="sidebar">
      <ul className="menu">
        <li className="menu-item active">
          <i className="fa fa-home" /> 
        </li>
        <li className="menu-item">
          <i className="fa fa-file-alt" />
        </li>
        <li className="menu-item">
          <i className="fa fa-users" />
        </li>
        <li className="menu-item">
          <i className="fa fa-chart-bar" />
        </li>
      </ul>
    </div>
  );
};

const StatCard = ({ title, count, icon }) => {
  return (
    <div className="stat-card">
      
      <div className="stat-info">
      <p>{title}</p>
      <div className="stat-icon">
        <i className={icon} />
      </div>
        <h2>{count}</h2>
        <button className="stat-button">Show more</button>
      </div>
    </div>
  );
};

// const Calendar = () => {
//   return (
//     <div className="calendar">
//       <header className="calendar-header">
//         <h3>December, 2024</h3>
//         <div className="calendar-controls">
//           <button>&lt;</button>
//           <button>&gt;</button>
//           <button>+</button>
//         </div>
//       </header>
//       <table className="calendar-grid">
//         <thead>
//           <tr>
//             {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
//               <th key={day}>{day}</th>
//             ))}
//           </tr>
//         </thead>
//         <tbody>
//           {/* Sample dates for illustration */}
//           {[0, 1, 2, 3, 4].map((week, i) => (
//             <tr key={i}>
//               {[...Array(7)].map((_, day) => (
//                 <td key={day} className={day === 0 || day === 6 ? 'weekend' : ''}>
//                   {Math.random() > 0.5 ? '08' : '20'}
//                 </td>
//               ))}
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// const TaskForm = () => {
//   return (
//     <div className="task-form">
//       <h4>Add Task</h4>
//       <div className="task-inputs">
//         <div className="input-group">
//           <label>Date:</label>
//           <input type="text" placeholder="YYYY" />
//           <input type="text" placeholder="MM" />
//           <input type="text" placeholder="DD" />
//         </div>
//         <div className="input-group">
//           <input type="text" placeholder="Add title" />
//         </div>
//         <div className="input-group">
//           <input type="text" placeholder="Add your description" />
//         </div>
//       </div>
//       <button className="task-button">Add task</button>
//     </div>

//     );
// }
export default Dashboard